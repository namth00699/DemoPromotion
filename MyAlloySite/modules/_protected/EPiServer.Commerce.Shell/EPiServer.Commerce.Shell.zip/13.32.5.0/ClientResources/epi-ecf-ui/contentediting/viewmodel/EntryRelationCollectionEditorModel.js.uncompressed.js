﻿/* TODO: Much borrowed from AssociationCollectionEditorModel - consolidate */
define("epi-ecf-ui/contentediting/viewmodel/EntryRelationCollectionEditorModel", [
    // dojo
    "dojo/_base/declare",
    //epi-ecf-ui
    "./_BaseEntryCollectionEditorModel",
    //Resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.relationcollectioneditor"
],
function (
    //dojo
    declare,
    //epi-ecf-ui
    _BaseEntryCollectionEditorModel,
    // Resources
    res
) {
    return declare([_BaseEntryCollectionEditorModel], {
        // module:
        //      epi-ecf-ui/contentediting/viewmodel/EntryRelationCollectionEditorModel
        // summary:
        //      Represents the model for bundle/package editors

        storeKey: "epi.commerce.relation",

        resources: res
    });
});