﻿define("epi-ecf-ui/contentediting/editors/SelectionEditorWithEmptyOption", [
    "dojo/_base/declare",
    "epi-cms/contentediting/editors/SelectionEditor"],
function (
    declare,
    SelectionEditor
) {
    return declare([SelectionEditor], {

        startup: function () {
            this.inherited(arguments);
            //clear state on startup to not show validation error before users have had any chance to set a value.
            this.set("state", null);
        },

        _setOptionsAttr: function (newOptions) {
            //this row is copied from /dijit/form/select widgets _setOptionsAttr.
            //I don't know what it does but I included just in case.
            this._isLoaded = false;
            //only show empty option when no value has been set.
            if (this.emptyOption && !this.get("value")) {
                var emptyOption = {
                    label: this.emptyOption,
                    disabled: true
                };
                newOptions.splice(0, 0, emptyOption);
            }
            this._set('options', newOptions);
        },

        _onFocus: function(){
            //we override _ValueRequiredMixin _onFocus because we don't want to validate on focus. Only onBlur
            this.onFocus();
        }
    });
});