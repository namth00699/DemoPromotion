﻿define("epi-ecf-ui/widget/viewmodel/PricingOverviewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/when",
    "dojo/Stateful",
    // EPi Framework
    "epi/dependency"
], function (
// dojo
    declare,
    when,
    Stateful,
    // EPi Framework
    dependency
) {
    return declare([Stateful], {
        // summary:
        //    Represents the Pricing overview widget's model.
        // model:
        //    "epi-ecf-ui/widget/viewmodel/PricingOverviewModel"
        // tags:
        //    public

        _customerGroupStore: null,

        _contentStructureStore: null,

        content: null,

        value: null,

        postscript: function () {
            // summary:
            //      Post properties mixin handler.
            // description:
            //      Set up model and resource for template binding.
            // tags:
            //      protected

            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._customerGroupStore = this._customerGroupStore || registry.get("epi.commerce.customergroup");
            this._contentStructureStore = this._contentStructureStore || registry.get("epi.cms.content.light");
        },

        populateData: function () {
            // summary:
            //      Loads data.
            // tags:
            //      protected

            when(this._customerGroupStore.query(), function (customerGroupList) {
                this.set("customerGroups", customerGroupList);
            }.bind(this));
        },

        _valueSetter: function (value) {
            // summary:
            //      Sets value for this widget.

            this.value = value;

            when(this._contentStructureStore.get(value), function (content) {
                this.set("content", content);
            }.bind(this));
        },

        getDefaultItem: function () {
            // summary:
            //      Get default price of the current content data.
            // tags:
            //      protected

            if (!this.content) {
                return null;
            }

            var priceTypeAll = 0;
            var priceTypePriceGroup = 2;

            return {
                contentLink: this.content.contentLink,
                name: this.content.name,
                code: this.content.properties.code,
                minQuantity: 0
            };
        }
    });
});
