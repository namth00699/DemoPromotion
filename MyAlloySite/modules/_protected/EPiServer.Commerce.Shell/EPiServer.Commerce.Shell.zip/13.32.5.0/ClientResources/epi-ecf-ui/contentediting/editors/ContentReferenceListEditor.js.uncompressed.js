﻿define("epi-ecf-ui/contentediting/editors/ContentReferenceListEditor", [
    // dojo
    "dojo/_base/declare",
    "dojo/aspect",
    // epi-cms
    "epi/shell/widget/dialog/Alert",
    "epi-cms/contentediting/editors/ContentReferenceListEditor",
    // epi commerce
    "epi-ecf-ui/widget/CatalogContentSelectorDialog",
    "./model/ContentReferenceListEditorModel",
    // resources
    "epi/i18n!epi/cms/nls/commerce.widget.contentreferencelisteditor"
], function(
    //dojo
    declare,
    aspect,
    // epi-cms
    Alert,
    BaseContentReferenceListEditor,
    // epi commerce
    CatalogContentSelectorDialog,
    ContentReferenceListEditorModel,
    // resources
    resources
) {
        return declare([BaseContentReferenceListEditor], {
            // summary:
            //      Represents the Content reference list editor in Commerce, which handles the Change context command as opening
            //      the content edit in Edit mode.

            itemEditorType: CatalogContentSelectorDialog,

            postMixInProperties: function() {
                // summary:
                //      Called after the parameters to the widget have been read-in,
                //      but before the widget template is instantiated.
                // tags:
                //      protected

                this.model = this.model || new ContentReferenceListEditorModel();

                this.inherited(arguments);

                if (this.isDistinctList) {
                    this.own(
                        aspect.around(this.model, "addItems", function(original) {

                            return function(items, existingItemIndex, before) {
                                // items: Array
                                //      The items added.
                                // existingItemIndex: Number
                                //      The index of an existing item.
                                // before: Boolean
                                //      Indicates that the new item should be added before the existing item.

                                var contentLink = items[0].contentLink;
                                if (this.model.get("contentLinks").indexOf(contentLink) === -1) {
                                    return original.apply(this.model, arguments);
                                }
                                else {
                                    this._showAlert();
                                }
                            }.bind(this);

                        }.bind(this))
                    );
                }
            },

            _showAlert: function() {
                // summary:
                //      Show alert message when add an item already exists in the list
                // tags:
                //      private

                var dialog = new Alert({
                    heading: resources.dialog.heading,
                    description: resources.dialog.description
                });

                dialog.show();
            }
        });
    });