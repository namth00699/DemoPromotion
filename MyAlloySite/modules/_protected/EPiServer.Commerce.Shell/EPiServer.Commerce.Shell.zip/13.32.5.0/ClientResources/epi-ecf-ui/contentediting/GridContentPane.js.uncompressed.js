require({cache:{
'url:epi-ecf-ui/contentediting/templates/GridContentPane.html':"<div class=\"dijitContentPane\">\r\n    <div data-dojo-attach-point=\"containerNode\" class=\"epi-grid epi-grid--limit-width\">\r\n        <div class=\"epi-grid__row epi-grid__row--no-border\">\r\n            <div class=\"epi-grid__col--12\">\r\n                <div class=\"epi-grid__header\">\r\n                    <h1 data-dojo-attach-point=\"headerNode\"></h1>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>"}});
define("epi-ecf-ui/contentediting/GridContentPane", [
// dojo
    "dojo/_base/declare",
    "dojo/dom-construct",
// dijit
    "dijit/_TemplatedMixin",
    "dijit/layout/_LayoutWidget",
// resources
    "dojo/text!./templates/GridContentPane.html"
], function (
// dojo
    declare,
    domConstruct,
// dijit
    _TemplatedMixin,
    _LayoutWidget,
// resources
    template
) {
    return declare([_LayoutWidget, _TemplatedMixin], {
        // summary:
        //      A content pane used to display its child widgets in a grid layout.
        //      It will add wrapping rows and column elements for child
        //      widgets as needed.
        // tags:
        //      internal

        templateString: template,

        _setHeaderAttr: { node: "headerNode", type: "innerHTML" },

        addChild: function(child) {

            var rowNode = this._getLastRow();
            if (!rowNode || child.hasOwnRow){
                rowNode = this._createRowNode();
            } else {
                var numberOfChildren = this._getNumberOfChildNodes(rowNode);
                var lastWidgetAdded = this._getLastWidgetAdded();
                if (numberOfChildren === 2 || lastWidgetAdded.hasOwnRow){
                    rowNode = this._createRowNode();
                }
            }
            var columnNode = this._createColumnNode(child.hasOwnRow, rowNode);
            child.placeAt(columnNode);

            // If I've been started but the child widget hasn't been started,
            // start it now.  Make sure to do this after widget has been
            // inserted into the DOM tree, so it can see that it's being controlled by me,
            // so it doesn't try to size itself.
            if(this._started && !child._started){
                child.startup();
            }
        },

        _getLastRow: function() {
            var rowNodes = this.containerNode.children;
            // the header is the first child and should not be included
            return rowNodes.length > 1 ? rowNodes[rowNodes.length-1] : null;
        },

        _createRowNode: function() {
            return domConstruct.create(
                "div",
                { "class": "epi-grid__row" },
                this.containerNode
            );
        },

        _getNumberOfChildNodes: function(node) {
            return node.children.length;
        },

        _getLastWidgetAdded: function() {
            var childWidgets = this.getChildren();
            return childWidgets.length > 0 ? childWidgets[childWidgets.length-1] : { hasOwnRow: false };
        },

        _createColumnNode: function(hasOwnRow, parentRow) {
            var columnSize = hasOwnRow ? 12 : 6;
            return domConstruct.create(
                "div",
                { "class": "epi-grid__col--" + columnSize },
                parentRow
            );
        }
    });
});