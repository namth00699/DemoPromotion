﻿define("epi-ecf-ui/widget/ExportedSubscriptionReportsList", [
    // dojo
    "dojo/_base/declare",
    "./ExportedOrderReportsList"
], function (
    // dojo
    declare,
    ExportedOrderReportsList
) {
    // module:
    //      epi-ecf-ui.widget.ExportedSubscriptionReportsList
    // tags:
    //      protected

    return declare([ExportedOrderReportsList], {
        // summary:
        //      Subscription report widget.
        // tags:
        //      public

        postCreate: function () {
            this.inherited(arguments);
        }
    });
});