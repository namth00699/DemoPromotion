require({cache:{
'url:epi-ecf-ui/widget/templates/SelectorItemTag.html':"<div class=\"dijitReset dijitLeft dijitInputField dijitInputContainer epi-categoryButton\">\r\n    <div class=\"dijitInline epi-resourceName\">\r\n        <div data-dojo-attach-point=\"textNode\" class=\"epi-textbox-tag__item dojoxEllipsis\"></div>\r\n        <div class=\"epi-removeButton\" tabindex=\"0\" data-dojo-attach-event=\"onclick:_onClick,onkeydown:_onKeyDown\"></div>\r\n    </div>\r\n</div>"}});
﻿define("epi-ecf-ui/widget/SelectorItemTag", [
// dojo
    "dojo/_base/declare",
    "dojo/keys",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/Tooltip",

// epi
    "epi/shell/dgrid/util/misc",

// resources
    "dojo/text!./templates/SelectorItemTag.html"
],

function (
// dojo
    declare,
    keys,

// dijit
    _TemplatedMixin,
    _WidgetBase,
    Tooltip,

// epi
    shellMisc,

// resources
    template
) {

    return declare([_WidgetBase, _TemplatedMixin], {
        // summary:
        //      A widget represents a button tag of an marketing item.
        // tags:
        //      internal

        templateString: template,

        item: null,

        postCreate: function () {
            // summary:
            //      Set text for the button tag.
            // tags:
            //      protected

            this.inherited(arguments);

            if (this.item !== null) {
                this.textNode.innerHTML = shellMisc.htmlEncode(this.item.name);
                new Tooltip({
                    connectId: this.textNode,
                    label: this._getTooltipLabel()
                });
            }
        },

        _getTooltipLabel: function(){
            return shellMisc.htmlEncode(this.item.name);
        },

        _onClick: function () {
            this.onRemoveClick(this.item.id);
        },

        onRemoveClick: function (id) {
            //summary:
            //    Handle the remove button click
            // tags:
            //    protected
        },

        _onKeyDown: function(event) {
            if (event.keyCode === keys.ENTER || event.keyCode === keys.SPACE) {
                this._onClick();
            }
        }
    });
});