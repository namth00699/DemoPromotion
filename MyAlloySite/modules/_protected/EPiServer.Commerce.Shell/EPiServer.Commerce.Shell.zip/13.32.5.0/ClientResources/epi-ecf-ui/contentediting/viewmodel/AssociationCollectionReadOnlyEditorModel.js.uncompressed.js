﻿define("epi-ecf-ui/contentediting/viewmodel/AssociationCollectionReadOnlyEditorModel", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "./ReadOnlyCollectionEditorModel"
],
function (
    //dojo
    declare,
    lang,

    ReadOnlyCollectionEditorModel
) {
    return declare([ReadOnlyCollectionEditorModel], {
        // module: 
        //      epi-ecf-ui/contentediting/viewmodel/AssociationCollectionEditorModel
        // summary:
        //      Represents the model for AssocciationCollectionEditor

        _storeKey: "epi.commerce.association"
    });
});